#ifndef TOOLS_H
#define TOOLS_H

unsigned char itoa(unsigned int i);
char* convert_mmsscc(unsigned var_cc, unsigned var_cs, unsigned var_cm);
char* convert_hhmmss(unsigned var_hs, unsigned var_hm, unsigned var_hh);


#endif